package com.exponent.bankapllication.serviceimpl;

import java.util.Scanner;

import com.exponent.bankapplication.modal.account;
import com.exponent.bankapplication.service.RBI;
public class SBI implements RBI{
	
	Scanner sc=new Scanner(System.in);
	account ac=new account();


	@Override
	public void createaccount() {
		// TODO Auto-generated method stub
		
		System.out.println("enter your account number");
		int accno=sc.nextInt();
		ac.setAccountno(accno);
		System.out.println("enter your account name");
		ac.setAccname(sc.next());
		System.out.println("enter your addhar card");
		ac.setAddharcard(sc.next());
		System.out.println("enter your pan card");
		ac.setPancard(sc.next());
		System.out.println("enter your contact number");
		ac.setContct(sc.nextLong());
		System.out.println("enter your email id");
		ac.setEmail(sc.next());
		System.out.println("enter your account balance");
		ac.setAccountbalance(sc.nextDouble());
		System.out.println("******account create succesfull*******");
	}

	@Override
	public void showaccountdetails() {
		// TODO Auto-generated method stub
		System.out.println("enter your account number");
		int accno=sc.nextInt();
		if(ac.getAccountno()==accno)
		{
			System.out.println(ac);
		} else {
			System.out.println("account does not exits");
		}
	}

	@Override
	public void showaccountbalance() {
		// TODO Auto-generated method stub
		
		System.out.println("enter your account number");
		int accno=sc.nextInt();
		if(ac.getAccountno()==accno)
		{
			System.out.println("your account balance is\t"+ac.getAccountbalance());
		} else {
			System.out.println("account does not exits");
		}
	}

	@Override
	public void depositmoney() {
		// TODO Auto-generated method stub
		
		System.out.println("enter your account no");
		int accno=sc.nextInt();
		if(ac.getAccountno()==accno)
		{
			//System.out.println("enter your deposit ammount");
		}
		else {
			System.out.println("account doesnot exist");
		}
		System.out.println("enter your deposit amount");
		int a=sc.nextInt();
		double  updatedbalance=ac.getAccountbalance()+a;
		ac.setAccountbalance(updatedbalance);
		System.out.println("updated balance is"+ac.getAccountbalance());
		
	}

	@Override
	public void withdralmoney() {
		// TODO Auto-generated method stub
		System.out.println("enter your account no");
		int accno=sc.nextInt();
		if(ac.getAccountno()==accno)
		{
			//System.out.println("enter your deposit ammount");
		}
		else {
			System.out.println("account doesnot exist");
		}
		System.out.println("enter your witdrawl  amount");
		int a=sc.nextInt();
		double  updatedbalance=ac.getAccountbalance()-a;
		ac.setAccountbalance(updatedbalance);
		System.out.println(" your updated witdrwal balance is"+ac.getAccountbalance());
		
	}

	@Override
	public void updateaccountdetails() {
		// TODO Auto-generated method stub
		
	}
}
	
	
	