package com.exponent.bankapplication.modal;

public class account {
	private int accountno;
	private String accname;
	private String addharcard;
	private String pancard;
	private long contct;
	private String email;
	private double accountbalance;
	//private double withdrwalmoney;
	//public double getWithdrwalmoney() {
	//	return withdrwalmoney;
	//}
	//public void setWithdrwalmoney(double withdrwalmoney) {
	//	this.withdrwalmoney = withdrwalmoney;
	//}
	public int getAccountno() {
		return accountno;
	}
	public void setAccountno(int accountno) {
		this.accountno = accountno;
	}
	public String getAccname() {
		return accname;
	}
	public void setAccname(String accname) {
		this.accname = accname;
	}
	public String getAddharcard() {
		return addharcard;
	}
	public void setAddharcard(String addharcard) {
		this.addharcard = addharcard;
	}
	public String getPancard() {
		return pancard;
	}
	public void setPancard(String pancard) {
		this.pancard = pancard;
	}
	public long getContct() {
		return contct;
	}
	public void setContct(long contct) {
		this.contct = contct;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public double getAccountbalance() {
		return accountbalance;
	}
	public void setAccountbalance(double accountbalance) {
		this.accountbalance = accountbalance;
		
		
	}
	@Override
	public String toString() {
		return "account [accountno=" + accountno + ", accname=" + accname + ", addharcard=" + addharcard + ", pancard="
				+ pancard + ", contct=" + contct + ", email=" + email + ", accountbalance=" + accountbalance + "]";
	}
	
	

}
