package com.exponent.bankapplication.service;

public interface RBI {
	
	public void createaccount();
	
	
	public void showaccountdetails();
	
	
	public void showaccountbalance();
	
	

	
	public void depositmoney();
	
	
	
	
	public void withdralmoney();
	
	
	
	public void updateaccountdetails();
	
	
	
	
	
	
	
	
	
	
	
	

}
