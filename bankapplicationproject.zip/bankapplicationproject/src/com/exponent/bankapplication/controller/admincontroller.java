package com.exponent.bankapplication.controller;



import java.util.Scanner;

import com.exponent.bankapllication.serviceimpl.SBI;
import com.exponent.bankapplication.service.RBI;


public class admincontroller {
	

	
	public static void main(String[] args) {
		
		System.out.println("----welcome to SBI bank------");
		
		
	//Scanner sc=new Scanner(System.in);
	Scanner sc=new Scanner(System.in);
	boolean flag=true;
	RBI rbi=new SBI();
	while(flag)
	{
		System.out.println("----bank account process ----");
		System.out.println("--------------------------------");
		System.out.println(" 1] create bank account         |");
		System.out.println("2] show account details         |");
		System.out.println("3] show account balance         |");
		System.out.println("4] withdral money               |");
		System.out.println("5] deposit money                |");
		System.out.println("6] update account details       |");
	
		System.out.println("7]exit                          |");
		System.out.println("--------------------------------");
		
		
		System.out.println("enter your choice between 1to 7s");
int ch=sc.nextInt();
	
	switch(ch)
	{
	case 1:
		rbi.createaccount();
		break;
	case 2:
	rbi.showaccountdetails();
	break;
	case 3:
		rbi.showaccountbalance();
		break;
	case 4:
		rbi.withdralmoney();
		break;
	case 5:
		rbi.depositmoney();
		break;
	case 6:
		rbi.updateaccountdetails();
		break;
	case 7:
		flag=false;
		break;
		
		default:
			System.out.println(" please enter correct choice");
	
	}
	}
	
	
	
	
		
		
	}

}
