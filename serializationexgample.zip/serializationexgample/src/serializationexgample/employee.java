package serializationexgample;

import java.io.Serializable;

public class employee implements Serializable  {
	
	
	
	private int empid;
	private String name;
	private String address;
	private int empno;
	private String emppass;
	public int getEmpid() {
		return empid;
	}
	public void setEmpid(int empid) {
		this.empid = empid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public int getEmpno() {
		return empno;
	}
	public void setEmpno(int empno) {
		this.empno = empno;
	}
	public String getEmppass() {
		return emppass;
	}
	public void setEmppass(String emppass) {
		this.emppass = emppass;
	}
	@Override
	public String toString() {
		return "employee [empid=" + empid + ", name=" + name + ", address=" + address + ", empno=" + empno
				+ ", emppass=" + emppass + "]";
	}
	

}
