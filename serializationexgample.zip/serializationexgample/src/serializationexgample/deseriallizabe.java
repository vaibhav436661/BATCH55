package serializationexgample;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;

public class deseriallizabe {

	
	
	
	
	
	public static void main(String[] args) throws IOException, ClassNotFoundException {
		FileInputStream file = new FileInputStream("employedetails.txt");
		ObjectInputStream obj = new ObjectInputStream(file);
	employee emp=(employee)	obj.readObject();
	System.out.println(emp);
	}
}
