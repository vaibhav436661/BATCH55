package serializationexgample;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

public class student {
	
	public static void main(String[] args) throws IOException {
		employee emp=new employee();
		emp.setAddress("pcmx");
			emp.setEmpid(12);
				emp.setEmpno(13);
				emp.setEmppass("iduywed");
				emp.setName("rahul");
				
				FileOutputStream file=new FileOutputStream("employedetails.txt");
				ObjectOutputStream obj=new ObjectOutputStream(file);
				obj.writeObject(emp);
				System.out.println("object serialized");
				
				
				
	}

}
