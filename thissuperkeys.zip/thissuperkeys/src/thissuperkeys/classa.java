package thissuperkeys;

public class classa {
	int a=10;
	String sname="vaibhav";
	int b=43;
	
	
	
	public void m1()
	{
		System.out.println("m1 method from parent class");
	}
	public void m2()
	{
		System.out.println("classa m2");
	}
}

