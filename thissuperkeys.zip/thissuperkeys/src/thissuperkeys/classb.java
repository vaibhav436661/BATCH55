package thissuperkeys;

public class classb extends classa {
	int a=100;
	String sname="vaibhav";
	int b=53;
	
	
	public void m2()
	{
		System.out.println("m2 method child class");
	}
	
	

	public void m1() {
		
		System.out.println("m1 method b class");
	}
	public void display()
	{
		System.out.println(super.a);
		super.m1();
	}
	public void samedetails()
	{
		System.out.println(this.b);
this.m2();	}
public static void main(String[] args) {
	classb cla=new classb();
	cla.display();
	cla.samedetails();
}
}
