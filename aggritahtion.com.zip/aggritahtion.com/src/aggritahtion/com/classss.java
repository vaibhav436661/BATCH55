package aggritahtion.com;

public class classss {
	String stdaddr;
	String stdlocaladdr;
	String stdperaddr;
	
	public String getStdaddr() {
		return stdaddr;
	}
	public void setStdaddr(String stdaddr) {
		this.stdaddr = stdaddr;
	}
	public String getStdlocaladdr() {
		return stdlocaladdr;
	}
	public void setStdlocaladdr(String stdlocaladdr) {
		this.stdlocaladdr = stdlocaladdr;
	}
	public String getStdperaddr() {
		return stdperaddr;
	}
	public void setStdperaddr(String stdperaddr) {
		this.stdperaddr = stdperaddr;
	}
	

}
