package aggritahtion.com;

public class student {
int stdid;
String stdname;
String classname;

classss classss;



public int getStdid() {
	return stdid;
}

public void setStdid(int stdid) {
	this.stdid = stdid;
}

public String getStdname() {
	return stdname;
}

public void setStdname(String stdname) {
	this.stdname = stdname;
}

public String getClassname() {
	return classname;
}

public void setClassname(String classname) {
	this.classname = classname;
}

public classss getClassss() {
	return classss;
}

public void setClassss(classss classss) {
	this.classss = classss;
}


}
