package aggritahtion.com;

public class mainclass {
	public static void main(String[] args) {
		classss cla=new classss();
		student s1=new student();
				
		s1.setClassname("12thclass");
		s1.setClassss( cla);
		s1.setStdid(21);
		s1.setStdname("rohit");
		
		
		cla.setStdaddr("pcmc");
		cla.setStdlocaladdr("pune");
		cla.setStdperaddr("maharsartra");
		
		
		
		System.out.println(s1.getClassname()+" "+s1.getClassss().getStdlocaladdr());
		
		
		
		
	}

}
