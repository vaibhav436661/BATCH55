/**
 * 
 */
/**
 * 
 */
module staticnonstatic {
}