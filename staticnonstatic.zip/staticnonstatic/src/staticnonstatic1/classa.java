package staticnonstatic1;

public class classa {
	String name="vaibhav";
	 static int i=1;
	 
	 public static void m3()
	 {
		 System.out.println(i);
		 
	 }
	 public static void m1()
	 {
		 classa cla=new classa();
		 System.out.println("static method");
		 System.out.println(classa.i);
		System.out.println(cla.name);
		 
		
	 }
	 
	 static {
		 System.out.println("print 1st method");
	 }
	 
	 
	 
	 static {
		 System.out.println("print second method");
	 }
	 public static void main(String[] args) {
		 
		System.out.println(classa.i);
		m1();
		
		 
		 
		 
		 
		 
		 
		 
		 
		 
	}
	
	
	
	
	
	
	
	
	
	
	
	
	

}
