package polymorphismexgample1;

public class polyeexgamoke {
	
	
	public void m1(int i)
	{
		System.out.println("single m1 method");
	}
	
	public void m1(int i ,int j)
	{
		System.out.println("double parametrized method");
	}
	
	public void m1( int i, int j,int k)
	{
		System.out.println("triple parametrized method");
	}
	
	public void m1(String s)
	{
		System.out.println("m1 single string name");
	}
	
	protected final void m1(String s,String b)
	{
		System.out.println("last");
	}
	public static void main(String[] args) {
		polyeexgamoke p=new polyeexgamoke();
		p.m1(21,22,223);
		p.m1(22);
		p.m1(29,23);
		p.m1("tushar");
		p.m1("vishal","abhi");
		
	}
	
	
	
	
	
	
	
	

}
