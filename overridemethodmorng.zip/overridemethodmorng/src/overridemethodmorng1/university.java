package overridemethodmorng1;

public class university {
	
	public static void main(String[] args) {
		    
	student st=new student();
	student st1=new techer();
	student st2=new collage();
	
	techer t1=new techer();
	techer t2=new collage();
	collage coll=new collage();
	System.out.println("student class------------");
	st.m1();
	st.m2();
	st.m3();
	
	System.out.println("student techer override---------------");
	st1.m1();
	st1.m2();
	st1.m3();
	System.out.println("student collage override---------------------");
	st2.m1();
	st2.m2();
	st2.m3();
	System.out.println("techer class---------------");
	t1.m1();
	t1.m2();
	t1.m3();
	t1.m4();
	t1.m5();
	System.out.println("techer collage override---------------");
	
	t2.m1();
	t2.m2();
	t2.m3();
	t2.m4();
	t2.m5();
	System.out.println("collage class-----------------");
	coll.m1();
	coll.m2();
	coll.m3();
	coll.m4();
	coll.m5();
	coll.m6();
	
	
		
		
		
		
	}
	
	
	
	
	
	
	
	
	
	
	
}
