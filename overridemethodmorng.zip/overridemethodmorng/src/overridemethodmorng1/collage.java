package overridemethodmorng1;

public class collage extends techer {
	
	@Override
	public void m1() {
		// TODO Auto-generated method stub
		System.out.println("sushant roll no 5 at 9th std but div b is swati");	
		}
	@Override
	public void m2() {
		// TODO Auto-generated method stub
		System.out.println("amit roll no 6 at 9th std but division c class techer is anjali");
	}
	@Override
	public void m3() {
		// TODO Auto-generated method stub
		System.out.println("delete addmission abhi");
	}
	
	public void m6()
	{
		System.out.println("principal name is thakre sir");
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}
