package overridemethodmorng1;

public class student {
	public void m1()
	{
		System.out.println(" sushant roll no 5 at 9th std");
	}
public void m2()
{
	System.out.println("amit roll no 6 at 9th std");
}
public void m3()
{
	System.out.println("abhi roll no 7 at 9th std");
}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}
