package overridemethodmorng1;

public class techer extends student {
	
	
	@Override
	public void m1() {
		// TODO Auto-generated method stub
		System.out.println("sushant roll no 5 at 9th std but div b");
	}
	
	@Override
	public void m2() {
		// TODO Auto-generated method stub
		System.out.println("amit roll no 6 at 9th std but division c");
	}
	
	public void m4()
	{
		System.out.println("class techer div b swati");
	}
	
	public void m5()
	{
		System.out.println("class techer div c anjali");
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}
