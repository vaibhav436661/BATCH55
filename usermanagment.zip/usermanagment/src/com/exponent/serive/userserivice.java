package com.exponent.serive;

public interface userserivice {

	
	public void useradd();
	
	
	public void displayalluesr();
	
	
	
	public void displaysingleuser();
	
	
	public void updateuserdetails();
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
