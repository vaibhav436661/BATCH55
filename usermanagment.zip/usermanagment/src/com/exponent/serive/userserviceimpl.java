package com.exponent.serive;

import java.util.Scanner;

import com.exponenet.entity.user;

public class userserviceimpl implements userserivice {

	user u[]=new user[5];
	Scanner sc=new Scanner(System.in);
	
	
	@Override
	public void useradd() {
		// TODO Auto-generated method stub
		
		Scanner sc=new Scanner(System.in);
		boolean flag=true;
		System.out.println("how many user u want to add ");
		int n=sc.nextInt();
	for(int i=0;i<n;i++)
	{
		if (n<u.length) {
			System.out.println("------fill the information given below----------2");
			
		}else
		{
			System.out.println("plese select number 1 to 5");
			flag =false;
		}
	
		user user=new user();
		
		System.out.println("enter the name");
		user.setUsername(sc.next());
		
		System.out.println("enter user id");
		user.setUserid(sc.nextInt());
		
		System.out.println("enter user address");
		user.setUseraddress(sc.next());
		
		System.out.println(" enter user salary");
		user.setUsersalary(sc.nextLong());
		
		System.out.println("enter user gender");
		user.setUsergender(sc.next());
		
		System.out.println("enter user contactno");
		user.setUsercontact(sc.nextLong());
		
		System.out.println("enter user mailid");
		user.setUseraddress(sc.next());
		
		u[i]=user;
		
		System.out.println("user added");
		
	}
		
}

	@Override
	public void displayalluesr() {
		// TODO Auto-generated method stub
		
		
		
		
		System.out.println("all user are dipaly");
		for (user user : u) {
			System.out.println(user);
			
		}
		
	}

	@Override
	public void displaysingleuser() {
		// TODO Auto-generated method stub
		System.out.println("display single user");
Scanner sc =new Scanner(System.in);


System.out.println("enter the user id ");

int id =sc.nextInt();
for (user user : u) {
	if (user != null && user.getUserid()==id) {
		
		System.out.println(user);
		
	}
	
	
	
}


	}

	@Override
	public void updateuserdetails() {
		// TODO Auto-generated method stub
	//}
	}
}