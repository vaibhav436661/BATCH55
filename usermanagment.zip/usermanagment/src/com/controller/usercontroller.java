package com.controller;

import java.util.Scanner;

import com.exponent.serive.userserivice;
import com.exponent.serive.userserviceimpl;

public class usercontroller {
	
	public static void main(String[] args) {
		
		userserivice us=new userserviceimpl();
		Scanner sc=new Scanner(System.in);
		boolean flag=true;
		
		
	//	int  user1=sc.nextInt();
		
		while (flag) {
			System.out.println("******************************************");
			
			System.out.println(" enter the user details for  xyz company");
			
			System.out.println("1]enter user add");
			
			System.out.println("2] enter for diplay all user");
			
			System.out.println("3]enter for display single user");
			
			System.out.println("4] update user details");
			
			System.out.println("5] exist");
			
			System.out.println("choose number between 1 to 4");
			
			
			
			int ch=sc.nextInt();
			
			switch (ch) {
			case 1:
				us.useradd();
				
				break;
			case 2:
				us.displayalluesr();
				break;
				
			case 3:
				us.displaysingleuser();
				break;
				
			case 4:
				us.updateuserdetails();
				break;
				
			case 5:
				flag=false;

			default:
				System.out.println("you choose invalid number plese choose vailid number");
				break;
			}
		}
		
		}
		
		
		
		
		
		
	}


