package com.exponenet.entity;

public class user {
	
	
	
	private int userid;
	private String username;
	private String useraddress;
	private double usersalary;
	private String usergender;
	
	private long usercontact;
	private String usermail;
	public int getUserid() {
		return userid;
	}
	public void setUserid(int userid) {
		this.userid = userid;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getUseraddress() {
		return useraddress;
	}
	public void setUseraddress(String useraddress) {
		this.useraddress = useraddress;
	}
	public double getUsersalary() {
		return usersalary;
	}
	public void setUsersalary(double usersalary) {
		this.usersalary = usersalary;
	}
	public String getUsergender() {
		return usergender;
	}
	public void setUsergender(String usergender) {
		this.usergender = usergender;
	}
	
	public long getUsercontact() {
		return usercontact;
	}
	public void setUsercontact(long usercontact) {
		this.usercontact = usercontact;
	}
	public String getUsermail() {
		return usermail;
	}
	public void setUsermail(String usermail) {
		this.usermail = usermail;
	}
	@Override
	public String toString() {
		return "user [userid=" + userid + ", username=" + username + ", useraddress=" + useraddress + ", usersalary="
				+ usersalary + ", usergender=" + usergender + ", , usercontact=" + usercontact
				+ ", usermail=" + usermail + "]";
	}
	

}
