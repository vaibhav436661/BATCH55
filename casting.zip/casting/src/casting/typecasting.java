package casting;

public class typecasting {

public static void main(String[] args) {
	
	
	//windening casting 
	
	
	int i=10;
	double d=i;
	System.out.println(i);
	System.out.println(d);
	
	//narrowing casting
	
	double d1=325.89;
	int i1=(int)d1;
	System.out.println(d1);
	System.out.println(i1);
	
	short s=(short)i1;
	System.out.println(s);
	int i2=92;
	char c=(char)i2;
	System.out.println(c);
	
	
	
	
	
	
	
	
	
}
}
