package abc;

public class student {

	   private int id;
	 private String clhname;
private	long contno;


public  void setId(int studentid)
{
	id=studentid;
	
}
public int getId()
{
	return id;
}
	
	
	
	
	
	
	
	
	
	
	
}


 //acces modifier public private protected default
	
	
