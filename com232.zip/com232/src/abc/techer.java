package abc;

public class techer  {
	
	public static void main(String[] args) {
		student st=new student();
		st.setId(88);
		System.out.println(st.getId());
	}
}

