package abc;

public class university {

}
