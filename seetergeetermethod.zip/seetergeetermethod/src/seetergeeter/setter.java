package seetergeeter;

public class setter {
 private int id;
 private String sname;
 
 public void setIdid (int student)
 {
 id=student;
 
 
 }
	public int getId()
	{
		return id;
	}
	
	
	
	
}
