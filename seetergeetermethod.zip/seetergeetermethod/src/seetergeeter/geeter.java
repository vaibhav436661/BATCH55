package seetergeeter;

public class geeter {

	
	public static void main(String[] args) {
		setter set=new setter();
		set.setIdid(12);
		System.out.println(set.getId());
		
		
		
	}
}
